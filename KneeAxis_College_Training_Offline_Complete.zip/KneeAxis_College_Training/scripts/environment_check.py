"""
KneeAxis — Environment Check Script Bridge
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from environment_check import main

if __name__ == "__main__":
    sys.exit(main())
