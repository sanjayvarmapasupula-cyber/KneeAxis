"""
KneeAxis — Validate Manifest Script Bridge
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.validate_datasets import validate_datasets, main

if __name__ == "__main__":
    main()
