# KneeAxis — College GPU Model Training Package
**AI-Assisted 3D Knee Reconstruction & Arthroplasty Planning**

Welcome to the official, JupyterHub-ready model training package for KneeAxis. This self-contained directory contains everything required to train, validate, and export medical deep-learning models on a university or shared GPU cluster.

---

## 🚀 Quick Start in 3 Steps

### 1. Check Server Hardware & Environment
Open a terminal in JupyterHub (or run `notebooks/00_Server_Setup.ipynb`):
```bash
python environment_check.py
```
This verifies your Python version, TensorFlow GPU configuration, CUDA visibility, and memory growth settings.

### 2. Run the 30-Second Smoke Test
Confirm that 2D classification and 3D segmentation architectures, loss functions, and atomic checkpoint writers compile and execute cleanly:
```bash
python scripts/smoke_test.py
```

### 3. Launch Model Training
Choose your training task:
```bash
# Model A: Kellgren-Lawrence ResNet50 Classifier (OAI Dataset)
python scripts/train_classification.py --max-minutes 90

# Model B: 3D Knee U-Net Segmentation (OAIZIB-CM Dataset)
python scripts/train_segmentation.py --max-minutes 120
```
Or open the interactive Jupyter notebooks in `notebooks/`:
- `notebooks/02_ResNet50_Training.ipynb`
- `notebooks/03_3D_UNet_Training.ipynb`

---

## 📁 Package Directory Structure

```text
KneeAxis_College_Training/
├── README_FIRST.md             # This document: primary entrypoint & overview
├── config.yaml                 # Master configuration (paths, hyperparameters, time limits)
├── environment_check.py        # Comprehensive GPU and environment diagnostic tool
├── requirements-college.txt    # Minimal, clean dependencies for college GPU nodes
│
├── notebooks/                  # Interactive step-by-step Jupyter notebooks
│   ├── 00_Server_Setup.ipynb          # Hardware & environment verification
│   ├── 01_Dataset_Preparation.ipynb   # Manifest generation & dataset validation
│   ├── 02_ResNet50_Training.ipynb     # Interactive KL grading training
│   ├── 03_3D_UNet_Training.ipynb      # Interactive 3D U-Net volume segmentation
│   ├── 04_Model_Evaluation.ipynb      # Multi-metric evaluation (QWK, Dice, MOST)
│   └── 05_Export_Weights.ipynb        # Artifact packaging & hash verification
│
├── src/                        # Modular, production-tested training pipeline
│   ├── common/                 # Paths, GPU growth, metrics (QWK, Dice), checkpoint manager
│   ├── classification/         # ResNet50 model, subject split, train, eval, CLI predict
│   └── segmentation/           # 3D U-Net model, patch generator, train, sliding-window eval
│
├── scripts/                    # Command-line execution tools
│   ├── check_environment.py    # Environment diagnostic runner
│   ├── prepare_manifests.py    # Generates OAI/MOST/OAIZIB manifests without guessing
│   ├── validate_datasets.py    # Inspects image counts, shapes, and paired volumes
│   ├── smoke_test.py           # End-to-end synthetic verification (< 30s)
│   ├── train_classification.py # KL classifier training runner
│   ├── train_segmentation.py   # 3D U-Net training runner
│   ├── resume_training.py      # Resumes interrupted sessions from atomic checkpoints
│   ├── verify_saved_models.py  # Tests trained models against Express backend contracts
│   └── export_artifacts.py     # Bundles weights and checksums for download
│
├── integration/                # Fullstack integration documentation & test scripts
│   ├── model_contracts.json    # JSON schema of inference CLI and Express bindings
│   ├── MODEL_INTEGRATION_GUIDE.md  # How to drop weights into KneeAxis and toggle UI
│   └── inference_example.py    # Standalone script verifying trained weights locally
│
├── guides/                     # Exhaustive server and operational manuals
│   ├── JUPYTERHUB_SETUP.md     # Server setup, venv/conda, kernel registration
│   ├── DATASET_DOWNLOADS.md    # Links & instructions for OAI, MOST, OAIZIB-CM, TotalSeg
│   ├── TRAINING_GUIDE.md       # Hyperparameters, transfer learning, monitoring
│   ├── RESUME_GUIDE.md         # Checkpoint resumption, wall-clock time limit safety
│   └── TROUBLESHOOTING.md      # Resolving CUDA OOM, killed processes, quotas
│
├── datasets/                   # Target folders for raw images and NIfTI volumes
├── manifests/                  # Generated CSV splits (strictly subject-level)
├── checkpoints/                # Automatic timestamped run checkpoints and states
├── models/                     # Best trained model weights and configs
├── outputs/                    # Visualizations, confusion matrices, evaluation metrics
└── logs/                       # Training logs and execution traces
```

---

## 🛡️ Critical Architecture & Medical Integrity Rules

1. **Decoupled from Web Backend**:
   This package is completely independent of the Node.js/Express backend and React frontend. It runs self-contained on Linux/JupyterHub without Node.js or web dependencies.
2. **Subject-Level Split Only**:
   The OAI dataset splits are performed strictly by `subject_id` to ensure no images from the same patient exist across training and evaluation splits, preventing data leakage.
3. **No Fake Metrics or Placeholder Claims**:
   All metrics reported in training logs and evaluation scripts are computed directly from actual model predictions.
4. **OAIZIB-CM Label Boundaries (6 Classes)**:
   The OAIZIB-CM dataset contains annotations for:
   - 0: Background
   - 1: Distal Femur
   - 2: Femoral Cartilage
   - 3: Proximal Tibia
   - 4: Medial Tibial Cartilage
   - 5: Lateral Tibial Cartilage
   **Patella and Fibula are not annotated in OAIZIB-CM.** For external pre-annotation or baseline comparison, TotalSegmentator is documented in `guides/DATASET_DOWNLOADS.md`.
5. **Time-Limit Safety (`MAX_MINUTES`)**:
   University GPU jobs that are preempted or time-limited will exit gracefully at the end of the current epoch without losing progress.

---

## 📦 Exporting Trained Weights

When training is complete or sufficient epochs have elapsed:
```bash
python scripts/export_artifacts.py
```
This generates `KneeAxis_Trained_Artifacts.zip` in your package root. Transfer this zip back to your local development machine and follow `integration/MODEL_INTEGRATION_GUIDE.md` to enable real-model AI inference in your KneeAxis web dashboard.
