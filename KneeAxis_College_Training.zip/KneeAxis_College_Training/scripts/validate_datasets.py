"""
KneeAxis — Validate Datasets
==============================
Verify dataset directories, check file counts, inspect sample files,
and report readiness for training.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.common.paths import load_config, get_dataset_paths


def validate_oai(oai_root: Path) -> dict:
    """Validate OAI dataset directory."""
    result = {"exists": oai_root.is_dir(), "files": 0, "extensions": {}, "issues": []}
    if not result["exists"]:
        result["issues"].append(f"OAI directory not found: {oai_root}")
        return result

    image_exts = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".dcm"}
    for f in oai_root.rglob("*"):
        if f.is_file() and f.suffix.lower() in image_exts:
            result["files"] += 1
            ext = f.suffix.lower()
            result["extensions"][ext] = result["extensions"].get(ext, 0) + 1

    if result["files"] == 0:
        result["issues"].append("No image files found in OAI directory.")

    return result


def validate_oaizib(oaizib_root: Path) -> dict:
    """Validate OAIZIB-CM dataset directory."""
    result = {"exists": oaizib_root.is_dir(), "subfolders": {}, "issues": []}
    if not result["exists"]:
        result["issues"].append(f"OAIZIB-CM directory not found: {oaizib_root}")
        return result

    expected = ["imagesTr", "labelsTr", "imagesTs", "labelsTs"]
    for sub in expected:
        sub_path = oaizib_root / sub
        if sub_path.is_dir():
            nifti_files = list(sub_path.glob("*.nii.gz")) + list(sub_path.glob("*.nii"))
            result["subfolders"][sub] = len(nifti_files)
        else:
            result["subfolders"][sub] = 0
            result["issues"].append(f"Expected subfolder missing: {sub}")

    # Check image/label pairing
    for split in ["Tr", "Ts"]:
        img_dir = oaizib_root / f"images{split}"
        lbl_dir = oaizib_root / f"labels{split}"
        if img_dir.is_dir() and lbl_dir.is_dir():
            img_stems = {f.name.replace(".nii.gz", "").replace(".nii", "") for f in img_dir.glob("*.nii*")}
            lbl_stems = {f.name.replace(".nii.gz", "").replace(".nii", "") for f in lbl_dir.glob("*.nii*")}
            unpaired_imgs = img_stems - lbl_stems
            unpaired_lbls = lbl_stems - img_stems
            if unpaired_imgs:
                result["issues"].append(f"images{split} without labels: {len(unpaired_imgs)}")
            if unpaired_lbls:
                result["issues"].append(f"labels{split} without images: {len(unpaired_lbls)}")

    return result


def validate_most(most_root: Path) -> dict:
    """Validate MOST dataset directory."""
    result = {"exists": most_root.is_dir(), "files": 0, "issues": []}
    if not result["exists"]:
        result["issues"].append(f"MOST directory not found: {most_root}")
        return result

    image_exts = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".dcm"}
    for f in most_root.rglob("*"):
        if f.is_file() and f.suffix.lower() in image_exts:
            result["files"] += 1

    if result["files"] == 0:
        result["issues"].append("No image files found in MOST directory (optional).")

    return result


def main():
    cfg = load_config()
    ds_paths = get_dataset_paths(cfg)

    print("=" * 60)
    print("  KneeAxis — Dataset Validation Report")
    print("=" * 60)

    # OAI
    print(f"\n📂 OAI Dataset: {ds_paths['oai']}")
    oai = validate_oai(ds_paths["oai"])
    if oai["exists"]:
        print(f"   Image files: {oai['files']}")
        for ext, count in oai["extensions"].items():
            print(f"     {ext}: {count}")
    for issue in oai["issues"]:
        print(f"   ⚠️  {issue}")

    # OAIZIB-CM
    print(f"\n📂 OAIZIB-CM Dataset: {ds_paths['oaizib']}")
    oaizib = validate_oaizib(ds_paths["oaizib"])
    if oaizib["exists"]:
        for sub, count in oaizib["subfolders"].items():
            icon = "✅" if count > 0 else "❌"
            print(f"   {icon} {sub}: {count} NIfTI files")
    for issue in oaizib["issues"]:
        print(f"   ⚠️  {issue}")

    # MOST
    print(f"\n📂 MOST Dataset: {ds_paths['most']}")
    most = validate_most(ds_paths["most"])
    if most["exists"]:
        print(f"   Image files: {most['files']}")
    for issue in most["issues"]:
        print(f"   ℹ️  {issue}")

    # Overall
    all_issues = oai["issues"] + oaizib["issues"]
    critical = [i for i in all_issues if "not found" in i.lower()]

    print(f"\n{'='*60}")
    if critical:
        print(f"  ❌ {len(critical)} critical dataset issues found.")
        print(f"     Place datasets in the expected directories before training.")
    else:
        print(f"  ✅ Dataset directories validated successfully.")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
