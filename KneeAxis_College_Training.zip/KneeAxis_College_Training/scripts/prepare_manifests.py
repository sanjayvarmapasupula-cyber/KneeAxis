"""
KneeAxis — Prepare Manifests
==============================
Generate CSV manifest files from dataset directories.
Manifests are used by training and evaluation scripts.
"""

import sys
import csv
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.common.paths import load_config, get_dataset_paths, get_manifest_paths, resolve_path


def prepare_oai_manifest(
    oai_root: Path,
    output_path: Path,
    grade_file: Optional[Path] = None,
) -> int:
    """
    Generate OAI manifest CSV: path, subject_id, grade.

    IMPORTANT: KL grades must come from an external metadata file
    (e.g., OAI clinical data CSV). This script does NOT guess grades
    from filenames.

    If no grade_file is provided, it creates a template manifest that
    the user must fill in manually.

    Expected grade_file format (CSV):
        subject_id,grade,image_filename
    """
    oai_root = Path(oai_root)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    image_exts = {".png", ".jpg", ".jpeg", ".bmp", ".tiff"}

    # Collect all image files
    images = sorted([
        f for f in oai_root.rglob("*")
        if f.is_file() and f.suffix.lower() in image_exts
    ])

    if not images:
        print(f"⚠️  No images found in: {oai_root}")
        return 0

    if grade_file and Path(grade_file).is_file():
        # Load grade mapping from external file
        grade_map = {}
        with open(grade_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                key = row.get("image_filename", "").strip()
                if not key:
                    key = row.get("filename", "").strip()
                grade = row.get("grade", row.get("kl_grade", "")).strip()
                subject = row.get("subject_id", row.get("patient_id", "")).strip()
                if key and grade and subject:
                    try:
                        grade_map[key] = {"subject_id": subject, "grade": int(grade)}
                    except ValueError:
                        pass

        count = 0
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["path", "subject_id", "grade"])
            for img in images:
                info = grade_map.get(img.name)
                if info:
                    writer.writerow([str(img), info["subject_id"], info["grade"]])
                    count += 1

        print(f"✅ OAI manifest written: {output_path} ({count} entries)")
        return count

    else:
        # Create template manifest for user to fill
        print(f"ℹ️  No grade file provided. Creating template manifest.")
        print(f"   You MUST fill in subject_id and grade columns manually.")
        print(f"   Grades must be integers 0–4 (Kellgren-Lawrence).")
        print(f"   Do NOT guess grades from filenames.\n")

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["path", "subject_id", "grade"])
            for img in images:
                # Try to extract subject_id from directory structure
                parts = img.relative_to(oai_root).parts
                subject_guess = parts[0] if len(parts) > 1 else "UNKNOWN"
                writer.writerow([str(img), subject_guess, ""])

        print(f"⚠️  Template OAI manifest written: {output_path} ({len(images)} entries)")
        print(f"    Fill in the 'grade' column with actual KL grades before training.")
        return 0


def prepare_oaizib_manifest(oaizib_root: Path, output_path: Path) -> int:
    """
    Generate OAIZIB-CM manifest CSV: case_id, image, label.
    Matches image/label pairs by inspecting actual filenames.
    """
    oaizib_root = Path(oaizib_root)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    errors = []

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["case_id", "image", "label"])

        for split in ["Tr", "Ts"]:
            img_dir = oaizib_root / f"images{split}"
            lbl_dir = oaizib_root / f"labels{split}"

            if not img_dir.is_dir():
                print(f"  Skipping images{split}: directory not found")
                continue
            if not lbl_dir.is_dir():
                print(f"  ⚠️  labels{split} directory not found — skipping split")
                continue

            img_files = sorted(img_dir.glob("*.nii*"))
            for img_file in img_files:
                # Derive the expected label filename
                stem = img_file.name
                # Try exact match first
                lbl_file = lbl_dir / stem
                if not lbl_file.is_file():
                    # Try common naming conventions
                    for alt_stem in [
                        stem,
                        stem.replace("_0000", ""),
                        stem.replace(".nii.gz", "_seg.nii.gz"),
                    ]:
                        candidate = lbl_dir / alt_stem
                        if candidate.is_file():
                            lbl_file = candidate
                            break

                if lbl_file.is_file():
                    case_id = img_file.stem.replace(".nii", "")
                    writer.writerow([case_id, str(img_file), str(lbl_file)])
                    count += 1
                else:
                    errors.append(f"No label for: {img_file.name}")

    if errors:
        print(f"  ⚠️  {len(errors)} unpaired images:")
        for e in errors[:10]:
            print(f"    {e}")

    print(f"✅ OAIZIB manifest written: {output_path} ({count} entries)")
    return count


def prepare_most_manifest(most_root: Path, output_path: Path) -> int:
    """Generate MOST manifest (same format as OAI)."""
    return prepare_oai_manifest(most_root, output_path, grade_file=None)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Prepare dataset manifests")
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--grade-file", type=str, default=None,
                        help="CSV with KL grades for OAI images")
    args = parser.parse_args()

    cfg = load_config(Path(args.config) if args.config else None)
    ds_paths = get_dataset_paths(cfg)
    mf_paths = get_manifest_paths(cfg)

    print("=" * 60)
    print("  KneeAxis — Manifest Preparation")
    print("=" * 60)

    grade_file = Path(args.grade_file) if args.grade_file else None

    if ds_paths["oai"].is_dir():
        print(f"\n📂 OAI: {ds_paths['oai']}")
        prepare_oai_manifest(ds_paths["oai"], mf_paths["oai"], grade_file)
    else:
        print(f"\n⚠️  OAI directory not found: {ds_paths['oai']}")

    if ds_paths["oaizib"].is_dir():
        print(f"\n📂 OAIZIB-CM: {ds_paths['oaizib']}")
        prepare_oaizib_manifest(ds_paths["oaizib"], mf_paths["oaizib"])
    else:
        print(f"\n⚠️  OAIZIB-CM directory not found: {ds_paths['oaizib']}")

    if ds_paths["most"].is_dir():
        print(f"\n📂 MOST: {ds_paths['most']}")
        prepare_most_manifest(ds_paths["most"], mf_paths["most"])
    else:
        print(f"\nℹ️  MOST directory not found (optional): {ds_paths['most']}")

    print(f"\n{'='*60}")
    print(f"  Manifest preparation complete.")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
