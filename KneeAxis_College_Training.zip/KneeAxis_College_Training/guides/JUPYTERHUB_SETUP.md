# KneeAxis — College JupyterHub Environment Setup Guide

This guide is designed for deploying and running the KneeAxis training package on university or shared high-performance computing (HPC) GPU servers running Linux and JupyterHub.

---

## 1. Prerequisites & Server Assessment

College GPU nodes frequently provide pre-installed NVIDIA drivers and CUDA modules. Before making any changes, inspect your environment:

Open a **Terminal** in JupyterHub and run:
```bash
nvidia-smi
```
Verify:
- GPU model (e.g., RTX 3090, RTX 4090, A100, V100, T4)
- Driver version and maximum CUDA version supported (e.g., CUDA 12.x or 11.8)
- GPU memory (VRAM) available

---

## 2. Directory Structure on JupyterHub

Upload `KneeAxis_College_Training.zip` to your personal home or scratch directory:
```bash
unzip KneeAxis_College_Training.zip -d KneeAxis_College_Training
cd KneeAxis_College_Training
```

Ensure scratch and storage permissions:
```bash
mkdir -p datasets checkpoints models outputs logs
chmod -R u+rwX .
```

---

## 3. Creating an Isolated Python Environment

> [!WARNING]
> **Do NOT install packages directly into the system Python or root environment.** This can corrupt shared server dependencies or cause permission errors.

### Option A: Using `venv` (Standard Python)
```bash
python3 -m venv ~/kneeaxis_env
source ~/kneeaxis_env/bin/activate
pip install --upgrade pip setuptools wheel
```

### Option B: Using Conda / Mamba (HPC Recommended)
If your university cluster provides Anaconda or Miniforge:
```bash
conda create -n kneeaxis_env python=3.10 -y
conda activate kneeaxis_env
```

---

## 4. Installing Dependencies

Install the requirements from `requirements-college.txt`:
```bash
pip install -r requirements-college.txt
```

> [!TIP]
> If TensorFlow with GPU support is already provided by the college module system (e.g., via `module load tensorflow` or `module load cuda`), **do not re-install TensorFlow with pip**. Check first by running:
> ```bash
> python environment_check.py
> ```

---

## 5. Registering the Environment as a Jupyter Kernel

To select your new environment inside Jupyter Notebooks:
```bash
pip install ipykernel
python -m ipykernel install --user --name=kneeaxis_env --display-name "Python (KneeAxis GPU)"
```

When opening any notebook in `notebooks/`, click **Kernel -> Change Kernel -> Python (KneeAxis GPU)**.

---

## 6. Running the Automated Diagnostic Check

Verify all hardware and software components before beginning data preparation:
```bash
python environment_check.py
```
**Expected Output:**
```text
======================================================================
 KneeAxis — College GPU Server Environment Diagnostic
======================================================================
[OK] Python version: 3.10.x
[OK] Package tensorflow is installed.
[OK] Package simpleitk is installed.
[OK] GPU count: 1
     GPU 0: NVIDIA A100-SXM4-40GB
[OK] Memory growth enabled for GPU:0
[OK] Temp/Scratch directory writable: ...
======================================================================
Diagnostic Summary: ALL CHECKS PASSED. Server is ready for training.
======================================================================
```
