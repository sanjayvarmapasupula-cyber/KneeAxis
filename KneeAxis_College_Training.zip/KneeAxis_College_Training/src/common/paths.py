"""
KneeAxis — Common Paths & Configuration Loader
================================================
Central path resolution and YAML configuration reader used by all
training, evaluation, and utility scripts.
"""

import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

# Ensure cross-platform UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def find_project_root(marker: str = "config.yaml") -> Path:
    """
    Walk upward from this file's location to find the training-package root,
    identified by the presence of ``marker`` (default: config.yaml).
    """
    current = Path(__file__).resolve().parent
    for _ in range(10):
        if (current / marker).is_file():
            return current
        current = current.parent
    # Fallback: assume two levels up from src/common/
    return Path(__file__).resolve().parent.parent.parent


PROJECT_ROOT: Path = find_project_root()


def load_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
    """Load the YAML configuration file and return as a dictionary."""
    try:
        import yaml
    except ImportError:
        print(
            "ERROR: PyYAML is not installed. Run:\n"
            "  pip install pyyaml\n",
            file=sys.stderr,
        )
        sys.exit(1)

    if config_path is None:
        config_path = PROJECT_ROOT / "config.yaml"

    config_path = Path(config_path).resolve()
    if not config_path.is_file():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    return cfg


def resolve_path(relative: str) -> Path:
    """Resolve a config-relative path against PROJECT_ROOT."""
    return (PROJECT_ROOT / relative).resolve()


# ---------------------------------------------------------------------------
# Pre-built convenience accessors
# ---------------------------------------------------------------------------

def get_dataset_paths(cfg: Dict[str, Any]) -> Dict[str, Path]:
    ds = cfg.get("datasets", {})
    return {
        "oai": resolve_path(ds.get("oai_root", "datasets/OAI")),
        "most": resolve_path(ds.get("most_root", "datasets/MOST")),
        "oaizib": resolve_path(ds.get("oaizib_root", "datasets/OAIZIB_CM")),
        "totalsegmentator": resolve_path(ds.get("totalsegmentator_root", "datasets/TotalSegmentator")),
    }


def get_manifest_paths(cfg: Dict[str, Any]) -> Dict[str, Path]:
    m = cfg.get("manifests", {})
    return {
        "oai": resolve_path(m.get("oai", "manifests/oai_manifest.csv")),
        "most": resolve_path(m.get("most", "manifests/most_manifest.csv")),
        "oaizib": resolve_path(m.get("oaizib", "manifests/oaizib_manifest.csv")),
    }


def get_output_paths(cfg: Dict[str, Any]) -> Dict[str, Path]:
    o = cfg.get("outputs", {})
    return {
        "checkpoints": resolve_path(o.get("checkpoints", "checkpoints")),
        "models": resolve_path(o.get("models", "models")),
        "logs": resolve_path(o.get("logs", "logs")),
        "evaluations": resolve_path(o.get("evaluations", "outputs/evaluations")),
        "classification": resolve_path(o.get("classification_outputs", "outputs/classification")),
        "segmentation": resolve_path(o.get("segmentation_outputs", "outputs/segmentation")),
    }


def ensure_directories(cfg: Dict[str, Any]) -> None:
    """Create all output directories if they do not exist."""
    for name, p in get_output_paths(cfg).items():
        p.mkdir(parents=True, exist_ok=True)
    # Sub-directories for checkpoints
    ckpt = resolve_path(cfg.get("outputs", {}).get("checkpoints", "checkpoints"))
    (ckpt / "classification").mkdir(parents=True, exist_ok=True)
    (ckpt / "segmentation").mkdir(parents=True, exist_ok=True)
    # Model output sub-directories
    models = resolve_path(cfg.get("outputs", {}).get("models", "models"))
    (models / "kl_classifier").mkdir(parents=True, exist_ok=True)
    (models / "knee_segmentation").mkdir(parents=True, exist_ok=True)
    # Manifests
    resolve_path("manifests").mkdir(parents=True, exist_ok=True)
