"""
KneeAxis — ResNet50 KL Classification Model
=============================================
Builds a TensorFlow/Keras ResNet50-based model for Kellgren-Lawrence
osteoarthritis grading (5 classes: KL0–KL4).
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import Tuple, Optional, Dict, Any


def build_resnet50_classifier(
    input_shape: Tuple[int, int, int] = (224, 224, 3),
    num_classes: int = 5,
    freeze_backbone: bool = True,
    dropout_rate: float = 0.3,
    label_smoothing: float = 0.1,
    learning_rate: float = 1e-4,
) -> keras.Model:
    """
    Build a ResNet50-based KL grade classifier.

    Parameters
    ----------
    input_shape : tuple
        (H, W, C) input image dimensions.
    num_classes : int
        Number of output classes (default 5 for KL0–KL4).
    freeze_backbone : bool
        If True, freeze all ResNet50 layers (for initial transfer learning).
    dropout_rate : float
        Dropout rate before the classification head.
    label_smoothing : float
        Label smoothing factor for the loss function.
    learning_rate : float
        Learning rate for the Adam optimiser.

    Returns
    -------
    keras.Model
        Compiled Keras model.
    """
    # Base model with ImageNet weights
    base_model = keras.applications.ResNet50(
        include_top=False,
        weights="imagenet",
        input_shape=input_shape,
        pooling=None,
    )
    base_model.trainable = not freeze_backbone

    # Classification head
    inputs = keras.Input(shape=input_shape, name="input_image")
    x = keras.applications.resnet50.preprocess_input(inputs)
    x = base_model(x, training=False)
    x = layers.GlobalAveragePooling2D(name="gap")(x)
    x = layers.Dropout(dropout_rate, name="dropout")(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="kl_output")(x)

    model = keras.Model(inputs=inputs, outputs=outputs, name="KneeAxis_ResNet50_KL")

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss=keras.losses.CategoricalCrossentropy(label_smoothing=label_smoothing),
        metrics=[
            "accuracy",
            keras.metrics.Precision(name="precision"),
            keras.metrics.Recall(name="recall"),
        ],
    )

    return model


def unfreeze_backbone(
    model: keras.Model,
    fine_tune_from_layer: int = 100,
    learning_rate: float = 1e-5,
    label_smoothing: float = 0.1,
) -> keras.Model:
    """
    Unfreeze the ResNet50 backbone from a given layer index onward
    and recompile with a lower learning rate for fine-tuning.
    """
    # Find the ResNet50 base model inside the functional model
    base = None
    for layer in model.layers:
        if isinstance(layer, keras.Model) and "resnet50" in layer.name.lower():
            base = layer
            break
    if base is None:
        # Flat model — just iterate layers
        for layer in model.layers[:fine_tune_from_layer]:
            layer.trainable = False
        for layer in model.layers[fine_tune_from_layer:]:
            layer.trainable = True
    else:
        base.trainable = True
        for layer in base.layers[:fine_tune_from_layer]:
            layer.trainable = False

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss=keras.losses.CategoricalCrossentropy(label_smoothing=label_smoothing),
        metrics=[
            "accuracy",
            keras.metrics.Precision(name="precision"),
            keras.metrics.Recall(name="recall"),
        ],
    )

    return model


def get_model_config(model: keras.Model) -> Dict[str, Any]:
    """
    Extract model configuration as a serialisable dictionary
    for saving alongside weights.
    """
    return {
        "model_name": "ResNet50_KL_Classifier",
        "num_classes": 5,
        "input_shape": list(model.input_shape[1:]),
        "class_mapping": {
            "0": "KL 0 - Normal",
            "1": "KL 1 - Doubtful",
            "2": "KL 2 - Minimal",
            "3": "KL 3 - Moderate",
            "4": "KL 4 - Severe",
        },
        "backbone": "ResNet50",
        "weights_file": "best.weights.h5",
        "framework": "TensorFlow/Keras",
        "preprocessing": "resnet50_preprocess_input",
        "total_params": int(model.count_params()),
    }
